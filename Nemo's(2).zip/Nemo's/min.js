document
  .getElementById("registrationForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Get form values
    var name = document.getElementById("name").value.trim(); // Trim leading/trailing spaces
    var sex = document.getElementById("sex").value;
    var attendance = document.getElementById("attendance").value.trim();
    var phoneNumber = document.getElementById("phoneNumber").value.trim();
    var password = document.getElementById("password").value.trim();

    // Basic validation (replace with more extensive validation if needed)
    var isValid = true;
    var errorMessage = "";

    if (name === "") {
      isValid = false;
      errorMessage = "Please enter your name.";
    } else if (phoneNumber === "") {
      isValid = false;
      errorMessage = "Please enter your phone number.";
    }

    // Update error message if validation fails
    if (!isValid) {
      document.getElementById("name").nextElementSibling.textContent =
        errorMessage;
      document.getElementById("name").nextElementSibling.style.display =
        "block";
      return; // Exit if validation fails
    }

    // Clear error messages on successful validation
    document.querySelectorAll(".error-message").forEach(function (message) {
      message.textContent = "";
      message.style.display = "none";
    });

    // Prepare data for next page
    var registeredData = [];
    if (sessionStorage.getItem("registeredData")) {
      registeredData = JSON.parse(sessionStorage.getItem("registeredData"));
    }
    registeredData.push({
      name: name,
      sex: sex,
      attendance: attendance,
      phoneNumber: phoneNumber,
    });

    // Store data in sessionStorage
    sessionStorage.setItem("registeredData", JSON.stringify(registeredData));

    // Redirect to next page
    window.location.href = "registered_names.html";
  });

// Additional code for registered_names.html

if (document.documentElement.clientWidth < 768) {
  // Add your responsive layout adjustments here (optional)
}

// Check if the current page is registered_names.html
if (document.documentElement.title === "Registered Names") {
  // Retrieve registered data from sessionStorage
  var registeredData = JSON.parse(sessionStorage.getItem("registeredData"));

  // Check if there's any data
  if (registeredData && registeredData.length > 0) {
    // Loop through registered data and create list items
    var registeredList = document.getElementById("registeredList");
    registeredData.forEach(function (person) {
      var listItem = document.createElement("li");
      listItem.textContent = `Name: ${person.name}, Sex: ${person.sex}, Attendance: ${person.attendance}, Phone: ${person.phoneNumber}`;
      registeredList.appendChild(listItem);
    });
  } else {
    // Display a message if there's no data
    var registeredList = document.getElementById("registeredList");
    registeredList.textContent = "No registered names found.";
  }
}
