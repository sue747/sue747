# Center Attendance 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Supriya-Rai-the-reactor/pen/YzMxMmJ](https://codepen.io/Supriya-Rai-the-reactor/pen/YzMxMmJ).

