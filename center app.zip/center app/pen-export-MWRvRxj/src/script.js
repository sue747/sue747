document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    // Here you can add your logic to verify the username and password
    // For simplicity, let's just print them for now
    console.log("Username:", username);
    console.log("Password:", password);
    // You can redirect the user to another page after successful login
    // For example: window.location.href = "dashboard.html";
});
